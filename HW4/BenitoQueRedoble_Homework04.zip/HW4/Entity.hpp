/*
|------------------------------------------------------|
|                     ENTITY HEADER                     |              
|------------------------------------------------------|
|   This is the header file (.hpp) file that contains  |
|   declarations for the Entity class along with the   | 
|   EntityState class and its subclasses.              |
|------------------------------------------------------|
*/

#ifndef ENTITY
#define ENTITY

#include <raylib.h>
#include <raymath.h>

const float WINDOW_WIDTH = 768.0f;
const float WINDOW_HEIGHT = 640.0f;

const Vector2 WORLD_MIN = {-640.0f, -640.0f};
// const Vector2 WORLD_MAX = {960.0f, 960.0f};

const float ELASTICITY = 0.0f;

std::set<int> walls;

int tile_size;

int col_count;
int row_count;
int rows_loaded;
int** grid;

bool is_key_active;
bool is_lock_active;

class Entity;

class EntityState {
public:
    virtual ~EntityState() {};
    virtual void Enter() = 0;
    virtual void Update(float delta_time) = 0;
    virtual void Exit() = 0;
};

class Entity {
public:
    std::string entity_type;

    Vector2 position;
    Vector2 min;
    Vector2 max;

    Color color;
    float HP = 0.0f;

    float damageTimer = 0.0f; //stops entity from taking damage every frame
    float damageQueue = 0.0f;

    Vector2 velocity = {0.0f, 0.0f};
    Vector2 acceleration = {0.0f, 0.0f};
    float speed = 0.0f;

    virtual ~Entity() {};

    virtual void Update(float delta_time) = 0;

    virtual void Draw() = 0;

    virtual void HandleEntityCollision(Entity* other) = 0;
    
    virtual void HandleWallCollisions() = 0;

    virtual void Reset(Vector2 new_pos) = 0;
};

#endif